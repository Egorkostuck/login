const buttonLog = document.querySelector('.button-logIn');
const error = document.getElementById('error-container');

const AuthUser = (data) => {
    return new Promise((resolve) => { // возвращает экземпляр объекта
        const userData ={
            name: 'Egor',
            password: '1234'
        }
        // result = {
            // status: true,
            // error: 'incorrect: password'
        // }
        setTimeout(() => {s
            if(userData.name === data.name){
                if(userData.password === data.password){
                    resolve({status: true,  error: ''}); // если все верно то сервер возвращает true
                } else{
                    resolve({status: true,  error: ''}); // если не верный пароль 
                }                
            } else {
                resolve({status: false,  error: 'incorrect: name'})
                error.classList.add('error');

            }
        },1000)

        
    });
}



buttonLog.addEventListener('click', () => {
    let name = document.querySelector('.login');
    let password = document.querySelector('.password');
    console.log('name: ' + name.value + ' password: ' + password.value);
    buttonLog.classList.add('loading');
    AuthUser({name: name.value, password: password.value}).then(result => {
        buttonLog.classList.remove('loading'); // убираем т.к. ответ от сервера пришел
        if(!result.status) {
            error.innerHTML = result.error;
            console.log(result)
        } else {
            buttonLog.classList.add('loading');
        }
    });  
});


